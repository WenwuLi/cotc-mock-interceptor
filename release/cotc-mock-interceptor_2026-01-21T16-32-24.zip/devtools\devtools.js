chrome.devtools.panels.create("cotc-mock-interceptor","","devtools/panel.html",r=>{if(chrome.runtime.lastError){console.error("DevTools 面板创建失败:",chrome.runtime.lastError);return}});
